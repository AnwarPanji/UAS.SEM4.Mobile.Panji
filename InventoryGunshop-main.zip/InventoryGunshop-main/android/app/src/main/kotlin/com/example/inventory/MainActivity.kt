package com.example.inventory

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
